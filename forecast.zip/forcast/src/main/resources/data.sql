insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Pune',PARSEDATETIME('11 Mar 2019, 00:00:02 AM','dd MMM yyyy, hh:mm:ss a','en'),10);
insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Mumbai',PARSEDATETIME('11 Mar 2019, 00:00:02 AM','dd MMM yyyy, hh:mm:ss a','en'),20);
insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Solapur',PARSEDATETIME('11 Mar 2019, 00:00:02 AM','dd MMM yyyy, hh:mm:ss a','en'),30);
insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Sangola',PARSEDATETIME('11 Mar 2019, 00:00:02 AM','dd MMM yyyy, hh:mm:ss a','en'),40);

insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Pune',PARSEDATETIME('11 Mar 2019, 01:00:01 AM','dd MMM yyyy, hh:mm:ss a','en'),10);
insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Mumbai',PARSEDATETIME('11 Mar 2019, 01:00:01 AM','dd MMM yyyy, hh:mm:ss a','en'),20);
insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Solapur',PARSEDATETIME('11 Mar 2019, 01:00:01 AM','dd MMM yyyy, hh:mm:ss a','en'),30);
insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Sangola',PARSEDATETIME('11 Mar 2019, 01:00:01 AM','dd MMM yyyy, hh:mm:ss a','en'),40);

insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Pune',PARSEDATETIME('11 Mar 2019, 02:00:01 AM','dd MMM yyyy, hh:mm:ss a','en'),10);
insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Mumbai',PARSEDATETIME('11 Mar 2019, 02:00:01 AM','dd MMM yyyy, hh:mm:ss a','en'),20);
insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Solapur',PARSEDATETIME('11 Mar 2019, 02:00:01 AM','dd MMM yyyy, hh:mm:ss a','en'),30);
insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Sangola',PARSEDATETIME('11 Mar 2019, 02:00:01 AM','dd MMM yyyy, hh:mm:ss a','en'),40);

insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Pune',PARSEDATETIME('11 Mar 2019, 03:00:01 AM','dd MMM yyyy, hh:mm:ss a','en'),40);
insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Mumbai',PARSEDATETIME('11 Mar 2019, 03:00:01 AM','dd MMM yyyy, hh:mm:ss a','en'),30);
insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Solapur',PARSEDATETIME('11 Mar 2019, 03:00:01 AM','dd MMM yyyy, hh:mm:ss a','en'),20);
insert into weather_details (city_Name,load_Date_Time,TEMPERATURE)
values ('Sangola',PARSEDATETIME('11 Mar 2019, 03:00:01 AM','dd MMM yyyy, hh:mm:ss a','en'),10);